// ====== DARK MODE SYNC ======
const body = document.body;
if (localStorage.getItem("theme") === "dark") body.classList.add("dark-mode");

const themeToggle = document.getElementById("theme-toggle");
if (themeToggle) {
  themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    localStorage.setItem("theme", body.classList.contains("dark-mode") ? "dark" : "light");
    themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  });
}

// ====== LOGOUT ======
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
  });
}


document.addEventListener("DOMContentLoaded", () => {
  const domainSelect = document.getElementById("domainSelect");
  const difficultySelect = document.getElementById("difficultySelect");
  const startBtn = document.getElementById("startInterview");
  const chatBox = document.getElementById("chatBox");
  const responseInput = document.getElementById("userResponse");
  const submitBtn = document.getElementById("submitAnswer");

  let currentIndex = 0;
  let questions = [];

  // === Question Bank ===
  const questionBank = {
    dsa: {
      beginner: [
        { q: "What is an array?", keywords: ["collection", "index", "same type", "fixed size"] },
        { q: "Explain what a stack is.", keywords: ["LIFO", "push", "pop", "top"] },
        { q: "What is a queue?", keywords: ["FIFO", "enqueue", "dequeue", "front", "rear"] }
      ],
      intermediate: [
        { q: "Explain how merge sort works.", keywords: ["divide", "conquer", "merge", "recursion"] },
        { q: "What is a binary search tree?", keywords: ["left", "right", "nodes", "sorted", "search"] }
      ],
      advanced: [
        { q: "What is dynamic programming?", keywords: ["overlapping", "subproblems", "memoization", "optimization"] },
        { q: "Explain Dijkstra’s algorithm.", keywords: ["shortest path", "graph", "weighted", "priority queue"] }
      ]
    },
    web: {
      beginner: [
        { q: "What is HTML used for?", keywords: ["structure", "markup", "content", "webpage"] },
        { q: "What is CSS?", keywords: ["style", "layout", "color", "design"] }
      ],
      intermediate: [
        { q: "Explain the difference between block and inline elements.", keywords: ["display", "width", "line", "layout"] },
        { q: "What is the DOM?", keywords: ["document", "object", "model", "tree", "structure"] }
      ],
      advanced: [
        { q: "What are React hooks?", keywords: ["state", "useEffect", "functional", "components"] },
        { q: "Explain RESTful APIs.", keywords: ["GET", "POST", "HTTP", "endpoint", "client-server"] }
      ]
    },
    python: {
      beginner: [
        { q: "What are Python data types?", keywords: ["int", "float", "string", "list", "tuple", "dict"] },
        { q: "What is indentation in Python?", keywords: ["whitespace", "syntax", "block", "error"] }
      ],
      intermediate: [
        { q: "Explain list comprehension.", keywords: ["shorter", "syntax", "loop", "expression"] },
        { q: "What are decorators in Python?", keywords: ["function", "wrapper", "modify", "behavior"] }
      ],
      advanced: [
        { q: "Explain Python generators.", keywords: ["yield", "iterator", "lazy", "memory"] },
        { q: "What is GIL (Global Interpreter Lock)?", keywords: ["thread", "mutex", "CPython", "parallel"] }
      ]
    },
    java: {
      beginner: [
        { q: "What is a class in Java?", keywords: ["blueprint", "object", "template", "fields", "methods"] },
        { q: "Explain inheritance.", keywords: ["extends", "parent", "child", "reuse", "hierarchy"] }
      ],
      intermediate: [
        { q: "What is polymorphism?", keywords: ["overloading", "overriding", "methods", "behavior"] },
        { q: "What are interfaces in Java?", keywords: ["contract", "implements", "methods", "abstract"] }
      ],
      advanced: [
        { q: "Explain multithreading in Java.", keywords: ["thread", "run", "synchronize", "parallel"] },
        { q: "What is JVM?", keywords: ["virtual machine", "bytecode", "execute", "platform independent"] }
      ]
    },
    ml: {
      beginner: [
        { q: "What is machine learning?", keywords: ["data", "model", "train", "predict", "algorithm"] },
        { q: "What is supervised learning?", keywords: ["labels", "training", "target", "input-output"] }
      ],
      intermediate: [
        { q: "Explain overfitting.", keywords: ["train", "test", "memorize", "generalize"] },
        { q: "What is feature scaling?", keywords: ["normalization", "standardization", "range"] }
      ],
      advanced: [
        { q: "What is a confusion matrix?", keywords: ["TP", "FP", "FN", "TN", "accuracy", "precision"] },
        { q: "Explain gradient descent.", keywords: ["loss", "optimization", "learning rate", "slope", "update"] }
      ]
    }
  };

  // === Start Interview ===
  startBtn.addEventListener("click", () => {
    const domain = domainSelect.value;
    const difficulty = difficultySelect.value;

    if (!domain || !difficulty) {
      addAIMessage("⚠️ Please select both a domain and difficulty level to begin.");
      return;
    }

    questions = questionBank[domain][difficulty];
    currentIndex = 0;

    chatBox.innerHTML = "";
    addAIMessage("🎯 Great! Let's start your " + domain.toUpperCase() + " interview. Here's your first question:");

    setTimeout(() => askQuestion(), 1000);

    responseInput.disabled = false;
    submitBtn.disabled = false;
  });

  // === Handle Answer Submission ===
  submitBtn.addEventListener("click", () => {
    const userAnswer = responseInput.value.trim().toLowerCase();
    if (!userAnswer) {
      addAIMessage("⚠️ Please type your answer before submitting.");
      return;
    }

    addUserMessage(userAnswer);

    const currentQ = questions[currentIndex];
    const matchCount = currentQ.keywords.filter(k => userAnswer.includes(k)).length;

    let feedback = "";
    if (matchCount === 0) {
      feedback = "❌ That’s not quite correct. Try mentioning terms like: " + currentQ.keywords.join(", ");
    } else if (matchCount < currentQ.keywords.length / 2) {
      feedback = "⚠️ You're on the right track. Consider including: " + currentQ.keywords.join(", ");
    } else {
      feedback = "✅ Excellent answer! You covered the important points well.";
    }

    addAIMessage(feedback);
    responseInput.value = "";

    currentIndex++;
    if (currentIndex < questions.length) {
      setTimeout(() => askQuestion(), 1500);
    } else {
      setTimeout(() => {
        addAIMessage("🎉 Interview complete! You did well. Review weak topics to improve even more.");
        responseInput.disabled = true;
        submitBtn.disabled = true;
      }, 1500);
    }
  });

  // === Ask Question ===
  function askQuestion() {
    const q = questions[currentIndex];
    addAIMessage("Q" + (currentIndex + 1) + ": " + q.q);
  }

  // === Helper: Add messages to chat ===
  function addAIMessage(text) {
    const div = document.createElement("div");
    div.className = "ai-message";
    div.textContent = text;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  function addUserMessage(text) {
    const div = document.createElement("div");
    div.className = "user-message";
    div.textContent = "🧑 " + text;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
});
