// ====== DARK / LIGHT MODE TOGGLE ======
const toggleBtn = document.getElementById('theme-toggle');
const body = document.body;

if(localStorage.getItem('theme') === 'dark'){
    body.classList.add('dark-mode');
    if(toggleBtn) toggleBtn.textContent = '☀️';
} else {
    body.classList.remove('dark-mode');
    if(toggleBtn) toggleBtn.textContent = '🌙';
}

if(toggleBtn) {
    toggleBtn.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        if(body.classList.contains('dark-mode')){
            localStorage.setItem('theme', 'dark');
            toggleBtn.textContent = '☀️';
        } else {
            localStorage.setItem('theme', 'light');
            toggleBtn.textContent = '🌙';
        }
    });
}

// ====== LOGIN FORM HANDLER ======
const loginForm = document.querySelector('.login-form');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();

        if(!username || !password){
            alert("Please enter both username and password!");
            return;
        }

        try {
            const response = await fetch("http://localhost:3000/api/login", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({username, password})
            });

            const data = await response.json();

            if(response.ok){
                localStorage.setItem("username", username);
                window.location.href = "dashboard.html";
            } else {
                alert("❌ " + (data.error || "Invalid credentials"));
            }
        } catch(err) {
            alert("⚠️ Cannot connect to server. Make sure backend is running.");
        }
    });
}

// ====== SIGNUP FORM HANDLER ======
const signupForm = document.getElementById('signupForm');
if(signupForm){
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('newUsername').value.trim();
        const password = document.getElementById('newPassword').value.trim();

        if(!username || !password){
            alert("Please enter both username and password!");
            return;
        }

        try {
            const response = await fetch("http://localhost:3000/api/signup", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({username, password})
            });

            const data = await response.json();

            if(response.ok){
                alert("✅ Account created successfully!");
                localStorage.setItem("username", username); // Directly go to dashboard
                window.location.href = "dashboard.html";
            } else {
                alert("❌ " + (data.error || "Something went wrong"));
            }
        } catch(err) {
            alert("⚠️ Cannot connect to server. Make sure backend is running.");
        }
    });
}

// ====== DASHBOARD FETCH ======
const dashboardContainer = document.querySelector('.dashboard-cards');
if(dashboardContainer){
    const username = localStorage.getItem("username");
    const userNameSpan = document.getElementById("userName");

    if(!username){
        alert("⚠️ No user found, redirecting to login.");
        window.location.href = "index.html#login";
    } else {
        fetch(`http://localhost:3000/api/dashboard/${username}`)
            .then(res => res.json())
            .then(data => {
                if(data.error){
                    alert("❌ " + data.error);
                    window.location.href = "index.html#login";
                    return;
                }

                if(userNameSpan) userNameSpan.textContent = data.username;

                document.getElementById("questionsAttempted").querySelector("p").textContent = data.questionsAttempted;
                document.getElementById("accuracy").querySelector("p").textContent = data.accuracy + "%";
                document.getElementById("codingChallenges").querySelector("p").textContent = data.codingChallenges;
                document.getElementById("readinessScore").querySelector("p").textContent = data.readinessScore + "/100";
                document.getElementById("learningProgress").querySelector("p").textContent = data.learningProgress + "%";
            })
            .catch(err => {
                alert("⚠️ Cannot fetch dashboard data.");
            });
    }
}

// ====== LOGOUT ======
const logoutBtn = document.getElementById("logoutBtn");
if(logoutBtn){
    logoutBtn.addEventListener("click", () => {
        localStorage.removeItem("username");
        window.location.href = "index.html#login";
    });
}