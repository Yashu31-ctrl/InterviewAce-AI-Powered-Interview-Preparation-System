const toggleBtn = document.getElementById('theme-toggle');
const body = document.body;

if(localStorage.getItem('theme') === 'dark'){
    body.classList.add('dark-mode');
    if(toggleBtn) toggleBtn.textContent = '☀️';
} else {
    body.classList.remove('dark-mode');
    if(toggleBtn) toggleBtn.textContent = '🌙';
}

if(toggleBtn) {
    toggleBtn.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        if(body.classList.contains('dark-mode')){
            localStorage.setItem('theme', 'dark');
            toggleBtn.textContent = '☀️';
        } else {
            localStorage.setItem('theme', 'light');
            toggleBtn.textContent = '🌙';
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
  const topicSelect = document.getElementById("topicSelect");
  const difficultySelect = document.getElementById("difficultySelect");
  const languageSelect = document.getElementById("languageSelect");
  const problemText = document.getElementById("problemText");
  const codeEditor = document.getElementById("codeEditor");
  const outputConsole = document.getElementById("outputConsole");
  const resultMessage = document.getElementById("resultMessage");
  const runBtn = document.getElementById("runCode");
  const submitBtn = document.getElementById("submitCode");
  const clearBtn = document.getElementById("clearCode");
  const generateBtn = document.getElementById("generateProblem");

  const problems = [
  // 🧮 Math
  {
    topic: "math",
    level: "beginner",
    title: "Sum of Two Numbers",
    text: "Write a program that takes two integers as input and prints their sum.",
    input: "3 5",
    expectedOutput: "8",
    keywords: ["+", "input", "print", "System.out.println", "int", "Scanner", "sum"]
  },
  {
    topic: "math",
    level: "beginner",
    title: "Check Even or Odd",
    text: "Write a program that checks if a number is even or odd.",
    input: "7",
    expectedOutput: "Odd",
    keywords: ["%", "if", "else", "input", "Scanner", "print", "System.out.println"]
  },
  {
    topic: "math",
    level: "intermediate",
    title: "Find Factorial",
    text: "Write a program to find the factorial of a given number.",
    input: "5",
    expectedOutput: "120",
    keywords: ["for", "range", "*", "int", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "math",
    level: "intermediate",
    title: "Prime Number Check",
    text: "Write a program that checks whether a number is prime or not.",
    input: "11",
    expectedOutput: "Prime",
    keywords: ["for", "if", "%", "break", "range", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "math",
    level: "advanced",
    title: "Find GCD of Two Numbers",
    text: "Write a program to find the greatest common divisor (GCD) of two numbers.",
    input: "36 60",
    expectedOutput: "12",
    keywords: ["while", "%", "if", "def", "function", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "math",
    level: "advanced",
    title: "Armstrong Number Check",
    text: "Check if a number is an Armstrong number (sum of cubes of digits = number).",
    input: "153",
    expectedOutput: "Armstrong",
    keywords: ["while", "%", "//", "**", "pow", "int", "Scanner", "input", "print", "System.out.println"]
  },

  // 🔢 Arrays
  {
    topic: "arrays",
    level: "beginner",
    title: "Find Maximum in Array",
    text: "Write a program to find the maximum element in an array.",
    input: "[1, 4, 2, 9, 5]",
    expectedOutput: "9",
    keywords: ["for", "max", ">", "int[]", "list", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "arrays",
    level: "beginner",
    title: "Sum of Array Elements",
    text: "Write a program to find the sum of all elements in an array.",
    input: "[2, 4, 6, 8]",
    expectedOutput: "20",
    keywords: ["for", "+=", "sum", "int[]", "list", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "arrays",
    level: "intermediate",
    title: "Find Second Largest Element",
    text: "Write a program that finds the second largest element in an array.",
    input: "[10, 20, 4, 45, 99]",
    expectedOutput: "45",
    keywords: ["sort", "for", "if", "int[]", "list", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "arrays",
    level: "intermediate",
    title: "Count Even Numbers in Array",
    text: "Count how many even numbers are present in an array.",
    input: "[3, 6, 8, 9, 10]",
    expectedOutput: "3",
    keywords: ["for", "if", "%", "count", "len", "int[]", "list", "print", "System.out.println"]
  },
  {
    topic: "arrays",
    level: "advanced",
    title: "Rotate Array by K Positions",
    text: "Write a program to rotate an array to the right by K steps.",
    input: "[1,2,3,4,5], K=2",
    expectedOutput: "[4,5,1,2,3]",
    keywords: ["for", "slice", "list", "len", "index", "array", "print", "System.out.println"]
  },

  // 🧵 Strings
  {
    topic: "strings",
    level: "beginner",
    title: "Reverse a String",
    text: "Write a program that takes a string and prints its reverse.",
    input: "hello",
    expectedOutput: "olleh",
    keywords: ["[::-1]", "reverse", "for", "len", "print", "System.out.println"]
  },
  {
    topic: "strings",
    level: "beginner",
    title: "Count Vowels in a String",
    text: "Write a program that counts the number of vowels in a string.",
    input: "apple",
    expectedOutput: "2",
    keywords: ["for", "in", "if", "contains", "vowels", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "strings",
    level: "intermediate",
    title: "Check Palindrome",
    text: "Write a program that checks whether a string is a palindrome.",
    input: "madam",
    expectedOutput: "Palindrome",
    keywords: ["==", "[::-1]", "equals", "lower", "trim", "print", "System.out.println"]
  },
  {
    topic: "strings",
    level: "intermediate",
    title: "Count Words in a Sentence",
    text: "Write a program that counts the number of words in a given sentence.",
    input: "I love programming",
    expectedOutput: "3",
    keywords: ["split", "len", "count", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "strings",
    level: "advanced",
    title: "Remove Duplicates from String",
    text: "Write a program to remove duplicate characters from a string.",
    input: "programming",
    expectedOutput: "progamin",
    keywords: ["set", "for", "if", "append", "StringBuilder", "print", "System.out.println"]
  },

  // 🔁 Loops
  {
    topic: "loops",
    level: "beginner",
    title: "Print 1 to N",
    text: "Write a program that prints numbers from 1 to N.",
    input: "5",
    expectedOutput: "1 2 3 4 5",
    keywords: ["for", "range", "i++", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "loops",
    level: "intermediate",
    title: "Sum of Digits",
    text: "Write a program that finds the sum of digits of a number.",
    input: "1234",
    expectedOutput: "10",
    keywords: ["//", "%", "while", "int", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "loops",
    level: "advanced",
    title: "Fibonacci Sequence",
    text: "Print the Fibonacci sequence up to N terms.",
    input: "7",
    expectedOutput: "0 1 1 2 3 5 8",
    keywords: ["for", "while", "next", "+", "print", "System.out.println"]
  },

  // 🔄 Recursion
  {
    topic: "recursion",
    level: "beginner",
    title: "Factorial using Recursion",
    text: "Write a recursive function to find the factorial of a number.",
    input: "5",
    expectedOutput: "120",
    keywords: ["def", "return", "recursion", "function", "if", "Scanner", "input", "System.out.println"]
  },
  {
    topic: "recursion",
    level: "intermediate",
    title: "Fibonacci using Recursion",
    text: "Print the Nth Fibonacci number using recursion.",
    input: "6",
    expectedOutput: "8",
    keywords: ["def", "return", "if", "recursion", "function", "System.out.println"]
  },

  // 🧩 Sorting & Searching
  {
    topic: "sorting",
    level: "beginner",
    title: "Sort an Array",
    text: "Write a program to sort an array in ascending order.",
    input: "[5, 2, 9, 1]",
    expectedOutput: "[1, 2, 5, 9]",
    keywords: ["sort", "for", "swap", "len", "int[]", "print", "System.out.println"]
  },
  {
    topic: "searching",
    level: "intermediate",
    title: "Linear Search",
    text: "Implement linear search to find an element in an array.",
    input: "[1,2,3,4,5], target=4",
    expectedOutput: "Found at index 3",
    keywords: ["for", "if", "==", "index", "Scanner", "input", "print", "System.out.println"]
  },
  {
    topic: "searching",
    level: "advanced",
    title: "Binary Search",
    text: "Implement binary search on a sorted array.",
    input: "[1,2,3,4,5,6,7,8,9], target=6",
    expectedOutput: "Found at index 5",
    keywords: ["while", "mid", "low", "high", "if", "else", "Scanner", "input", "print", "System.out.println"]
  },

  // ⭐ Patterns
  {
    topic: "patterns",
    level: "beginner",
    title: "Print Right Triangle Pattern",
    text: "Print a right triangle pattern of stars of height N.",
    input: "3",
    expectedOutput: "*\\n**\\n***",
    keywords: ["for", "print", "range", "nested", "System.out.println"]
  },
  {
    topic: "patterns",
    level: "intermediate",
    title: "Inverted Pyramid Pattern",
    text: "Print an inverted pyramid of stars with N rows.",
    input: "4",
    expectedOutput: "****\\n***\\n**\\n*",
    keywords: ["for", "print", "nested", "range", "System.out.println"]
  }
];
// Generate random problem
  generateBtn.addEventListener("click", () => {
    const topic = topicSelect.value;
    const level = difficultySelect.value;
    let filtered = problems.filter(
      (p) =>
        (topic === "all" || p.topic === topic) &&
        (level === "all" || p.level === level)
    );

    if (filtered.length === 0) {
      problemText.innerText = "No problems found for this selection.";
      return;
    }

    const problem = filtered[Math.floor(Math.random() * filtered.length)];
    problemText.innerHTML = `<strong>${problem.title}</strong><br>${problem.text}<br><br><b>Example Input:</b> ${problem.input}<br><b>Expected Output:</b> ${problem.expectedOutput}`;
    problemText.dataset.expected = problem.expectedOutput;
    problemText.dataset.keywords = JSON.stringify(problem.keywords);

    loadTemplate();
    outputConsole.textContent = "-- Output will appear here --";
    resultMessage.textContent = "";
  });

  // Load language template
  function loadTemplate() {
    const lang = languageSelect.value;
    if (lang === "java") {
      codeEditor.value = `import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Write your logic here
    }
}`;
    } else {
      codeEditor.value = `# Write your logic here
`;
    }
  }
  languageSelect.addEventListener("change", loadTemplate);

  // Run simulation
  runBtn.addEventListener("click", () => {
    const code = codeEditor.value.trim();
    const lang = languageSelect.value;

    if (!code) {
      outputConsole.textContent = "⚠️ Please write code first!";
      return;
    }

    if (lang === "python" && code.includes("print")) {
      outputConsole.textContent = "✅ Code executed successfully (simulated)";
    } else if (lang === "java" && code.includes("System.out.println")) {
      outputConsole.textContent = "✅ Java code compiled successfully (simulated)";
    } else {
      outputConsole.textContent = "⚠️ No output statement found!";
    }
  });

  // Submit - logic validation
  submitBtn.addEventListener("click", () => {
    const code = codeEditor.value;
    const expected = problemText.dataset.expected;
    const keywords = JSON.parse(problemText.dataset.keywords || "[]");

    if (!expected) {
      resultMessage.textContent = "⚠️ Please generate a problem first!";
      resultMessage.style.color = "orange";
      return;
    }

    let missing = keywords.filter((kw) => !code.includes(kw));

    if (missing.length === 0) {
      resultMessage.textContent = `✅ Correct Logic! Expected Output: ${expected}`;
      resultMessage.style.color = "limegreen";
    } else {
      resultMessage.textContent = "❌ Missing logic parts: " + missing.join(", ");
      resultMessage.style.color = "tomato";
    }
  });

  // Clear
  clearBtn.addEventListener("click", () => {
    codeEditor.value = "";
    outputConsole.textContent = "-- Output will appear here --";
    resultMessage.textContent = "";
  });
});