// ====== DARK MODE SYNC ======
const body = document.body;
if (localStorage.getItem("theme") === "dark") body.classList.add("dark-mode");

const themeToggle = document.getElementById("theme-toggle");
if (themeToggle) {
  themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    localStorage.setItem("theme", body.classList.contains("dark-mode") ? "dark" : "light");
    themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  });
}

// ====== LOGOUT ======
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
  });
}

const companyData = {
  google: [
    { q: "What is dynamic programming?", a: "An optimization technique that solves subproblems once and reuses results to solve larger problems." },
    { q: "Explain memoization.", a: "Caching results of function calls to avoid recomputation." },
    { q: "What is the time complexity of binary search?", a: "O(log n)" },
    { q: "Difference between BFS and DFS?", a: "BFS uses a queue; DFS uses a stack (or recursion)." },
    { q: "What are design patterns?", a: "Reusable solutions to common software design problems." },
    { q: "What is a deadlock?", a: "A situation where processes wait indefinitely for each other’s resources." },
    { q: "Explain garbage collection in Java.", a: "Automatically frees memory by removing unreferenced objects." },
    { q: "What is Big-O notation?", a: "Describes algorithm performance as input size grows." },
    { q: "Explain time vs space complexity.", a: "Time → execution speed; Space → memory usage." },
    { q: "What is an interface in Java?", a: "A contract specifying methods that must be implemented by a class." },
    { q: "Explain normalization in databases.", a: "Organizing data to reduce redundancy." },
    { q: "What is a race condition?", a: "Unexpected behavior from multiple threads accessing shared data." },
    { q: "Explain REST API.", a: "Architecture for designing networked applications using HTTP." },
    { q: "What is recursion?", a: "A function calling itself until a base condition is met." },
    { q: "Explain merge sort.", a: "Divide and conquer algorithm with O(n log n) complexity." },
    { q: "What are hash maps?", a: "Data structures storing key-value pairs using hash functions." },
    { q: "Explain overloading vs overriding.", a: "Compile-time vs runtime polymorphism." },
    { q: "How do you optimize SQL queries?", a: "Use indexes, avoid SELECT *, and use proper joins." },
    { q: "Tell me about a challenging coding bug you solved.", a: "HR-style question: describe problem, debugging, and resolution." },
    { q: "Why do you want to work at Google?", a: "To contribute to impactful technology and learn from world-class engineers." }
  ],

  microsoft: [
    { q: "Explain encapsulation.", a: "Binding data and methods that operate on it into a single unit." },
    { q: "What is polymorphism?", a: "Objects behaving differently based on context or input." },
    { q: "Explain abstraction in OOP.", a: "Hiding implementation details and exposing functionality." },
    { q: "What are async/await in Python?", a: "Used for asynchronous programming to handle non-blocking calls." },
    { q: "What is a thread?", a: "A unit of execution within a process." },
    { q: "Explain join types in SQL.", a: "INNER, LEFT, RIGHT, FULL – combine tables on key relationships." },
    { q: "What is cloud computing?", a: "Providing computing resources on-demand via the internet." },
    { q: "Explain dependency injection.", a: "Design pattern for supplying dependencies from outside the class." },
    { q: "What is the difference between stack and heap?", a: "Stack stores local variables; heap stores dynamically allocated memory." },
    { q: "What is a linked list?", a: "Collection of nodes with data and next pointers." },
    { q: "What is an exception?", a: "Error detected during program execution." },
    { q: "Explain MVC architecture.", a: "Separates app into Model, View, and Controller layers." },
    { q: "What are lambda expressions?", a: "Anonymous functions in Java or Python." },
    { q: "Explain inheritance.", a: "Deriving a new class from an existing one." },
    { q: "What is an API?", a: "Interface allowing software interaction between systems." },
    { q: "Explain difference between abstract class and interface.", a: "Abstract classes can have implemented methods; interfaces cannot (in older Java versions)." },
    { q: "How do you ensure code scalability?", a: "Use modular, maintainable, and efficient code with proper testing." },
    { q: "Tell me about a time you worked in a team.", a: "HR question about collaboration and conflict resolution." },
    { q: "What motivates you to join Microsoft?", a: "Learning culture, innovation, and impactful projects." },
    { q: "What is your favorite Microsoft product and why?", a: "Describe one and how you use or admire it." }
  ],

  amazon: [
    { q: "Explain two-pointer technique.", a: "Using two iterators to optimize traversal for arrays/lists." },
    { q: "What are Amazon’s Leadership Principles?", a: "Customer obsession, ownership, bias for action, etc." },
    { q: "Explain merge sort algorithm.", a: "Divide and conquer sort algorithm with O(n log n) complexity." },
    { q: "What is hashmap?", a: "Key-value data structure for constant-time lookup." },
    { q: "What is quicksort?", a: "Sorts by partitioning around a pivot; O(n log n) average." },
    { q: "Difference between array and linked list?", a: "Array fixed-size, random access; linked list dynamic, sequential." },
    { q: "What is recursion?", a: "Function calling itself until base condition is met." },
    { q: "Explain bubble sort.", a: "Repeatedly swaps adjacent elements if out of order." },
    { q: "What is big O notation?", a: "Describes algorithm performance as input grows." },
    { q: "What are SQL indexes?", a: "Speed up query performance by organizing data." },
    { q: "Explain REST API.", a: "Web service architecture using HTTP methods." },
    { q: "Explain polymorphism.", a: "Different objects responding to the same interface." },
    { q: "What is inheritance?", a: "Mechanism to derive new classes from existing ones." },
    { q: "Explain object-oriented design.", a: "Modeling system as interacting objects." },
    { q: "What is an exception in Java?", a: "Runtime error condition that can be handled." },
    { q: "Tell me about a difficult customer scenario you handled.", a: "HR question assessing ownership and communication." },
    { q: "How do you prioritize tasks?", a: "Use urgency vs importance and business impact." },
    { q: "Why Amazon?", a: "To innovate and impact millions of customers worldwide." },
    { q: "How do you handle failure?", a: "Reflect, learn, and iterate quickly." },
    { q: "Give an example of bias for action.", a: "Describe an instance where you made a decision swiftly and responsibly." }
  ],

  meta: [
    { q: "What is recursion?", a: "A function calling itself with a base condition." },
    { q: "Explain overloading vs overriding.", a: "Compile-time vs runtime polymorphism." },
    { q: "What are neural networks?", a: "Algorithms modeled after human brain for pattern recognition." },
    { q: "What is backpropagation?", a: "Algorithm for training neural networks by minimizing loss." },
    { q: "Explain time complexity.", a: "Measure of computational growth as input increases." },
    { q: "What are hash tables?", a: "Store data in key-value pairs using hashing." },
    { q: "What is a binary tree?", a: "Each node has at most two children." },
    { q: "What is gradient descent?", a: "Optimization algorithm to minimize cost function." },
    { q: "What is OOP?", a: "Programming paradigm based on objects and classes." },
    { q: "Explain normalization.", a: "Organizing data to eliminate redundancy." },
    { q: "What is SQL injection?", a: "Security vulnerability via malicious SQL queries." },
    { q: "What is JSON?", a: "Lightweight data-interchange format." },
    { q: "Explain REST vs GraphQL.", a: "REST uses endpoints; GraphQL fetches data via queries." },
    { q: "How do you handle project deadlines?", a: "Plan, prioritize, and communicate transparently." },
    { q: "Describe a time you improved performance.", a: "Optimized system or code for speed and efficiency." },
    { q: "Why Meta?", a: "To work on scalable products connecting billions of users." },
    { q: "How do you stay updated with tech?", a: "Read docs, blogs, attend tech talks, experiment." },
    { q: "What’s your favorite data structure?", a: "Depends on use-case; hashmaps for lookups, trees for hierarchy." },
    { q: "Explain AI ethics.", a: "Ensuring fairness, transparency, and safety in AI systems." },
    { q: "What is your strength as a developer?", a: "Logical problem solving and clean, maintainable code." }
  ],

  // Similarly for TCS, Infosys, Wipro, Accenture (trimmed below for brevity)
  // You can add 20 similar structured Q&A sets for them.
};

const companySelect = document.getElementById("companySelect");
const loadCompanySet = document.getElementById("loadCompanySet");
const questionContainer = document.getElementById("questionContainer");

loadCompanySet.addEventListener("click", () => {
  const selected = companySelect.value;
  questionContainer.innerHTML = "";

  if (!selected || !companyData[selected]) {
    questionContainer.innerHTML = "<p>Please select a valid company.</p>";
    return;
  }

  companyData[selected].forEach((item, index) => {
    const div = document.createElement("div");
    div.className = "question";
    div.innerHTML = `
      <h3>Q${index + 1}: ${item.q}</h3>
      <p><b>Answer:</b> ${item.a}</p>
      <button class="mark-btn">Mark Solved</button>
    `;
    div.querySelector(".mark-btn").addEventListener("click", (e) => {
      e.target.classList.toggle("marked");
      e.target.innerText = e.target.classList.contains("marked") ? "✅ Solved" : "Mark Solved";
    });
    questionContainer.appendChild(div);
  });
});
