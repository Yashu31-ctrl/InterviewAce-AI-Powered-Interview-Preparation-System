// ====== DARK MODE SYNC ======
const body = document.body;
if (localStorage.getItem("theme") === "dark") body.classList.add("dark-mode");

const themeToggle = document.getElementById("theme-toggle");
if (themeToggle) {
  themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    localStorage.setItem("theme", body.classList.contains("dark-mode") ? "dark" : "light");
    themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  });
}

// ====== LOGOUT ======
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
  });
}

// ====== QUESTION BANK DATA ======
const questionData = [
  // DSA
  { subject: "dsa", level: "beginner", question: "What is an array?", answer: "An array is a linear data structure that stores elements of the same type in contiguous memory locations." },
  { subject: "dsa", level: "intermediate", question: "What is a binary search tree?", answer: "A binary search tree is a binary tree where each node has a key greater than all keys in its left subtree and smaller than those in its right subtree." },
  { subject: "dsa", level: "advanced", question: "Explain dynamic programming with example.", answer: "Dynamic programming is an optimization technique used to solve complex problems by breaking them into overlapping subproblems (e.g., Fibonacci sequence)." },

  // HTML
  { subject: "html", level: "beginner", question: "What is HTML?", answer: "HTML stands for HyperText Markup Language used to structure web pages." },
  { subject: "html", level: "intermediate", question: "What are semantic HTML elements?", answer: "Semantic elements clearly describe their meaning in a human- and machine-readable way, like header, article, footer." },
  { subject: "html", level: "advanced", question: "How does HTML5 improve accessibility?", answer: "HTML5 provides new semantic tags that improve accessibility and search engine understanding." },

  // CSS
  { subject: "css", level: "beginner", question: "What is CSS used for?", answer: "CSS is used to style and layout web pages — colors, fonts, spacing, and animations." },
  { subject: "css", level: "intermediate", question: "Explain the box model in CSS.", answer: "The box model describes the rectangular boxes of elements including margin, border, padding, and content." },
  { subject: "css", level: "advanced", question: "What are CSS preprocessors?", answer: "Preprocessors like SASS and LESS allow variables, nesting, and modular CSS for maintainability." },

  // JavaScript
  { subject: "js", level: "beginner", question: "What is JavaScript?", answer: "JavaScript is a scripting language that enables dynamic functionality in web pages." },
  { subject: "js", level: "intermediate", question: "What is a closure in JS?", answer: "A closure gives access to an outer function’s scope from an inner function, even after the outer function has returned." },
  { subject: "js", level: "advanced", question: "Explain event loop in JS.", answer: "The event loop continuously checks the call stack and task queue to manage asynchronous operations." },

  // Machine Learning
  { subject: "ml", level: "beginner", question: "What is supervised learning?", answer: "Supervised learning uses labeled datasets to train models to predict outcomes." },
  { subject: "ml", level: "intermediate", question: "What is overfitting?", answer: "Overfitting occurs when a model performs well on training data but poorly on unseen data." },
  { subject: "ml", level: "advanced", question: "Explain gradient descent.", answer: "Gradient descent is an optimization algorithm used to minimize loss by adjusting weights iteratively." }
];

// ====== FILTER FUNCTION ======
const questionList = document.getElementById("question-list");
const subjectSelect = document.getElementById("subject-select");
const difficultySelect = document.getElementById("difficulty-select");

function renderQuestions() {
  const subject = subjectSelect.value;
  const level = difficultySelect.value;

  questionList.innerHTML = "";
  const filtered = questionData.filter(q =>
    (subject === "all" || q.subject === subject) &&
    (level === "all" || q.level === level)
  );

  filtered.forEach(q => {
    const card = document.createElement("div");
    card.classList.add("question-card");
    card.innerHTML = `
      <h3>${q.question}</h3>
      <button class="show-btn">Show Answer</button>
      <p class="answer">${q.answer}</p>
    `;
    const btn = card.querySelector(".show-btn");
    const ans = card.querySelector(".answer");
    btn.addEventListener("click", () => ans.classList.toggle("show-answer"));
    questionList.appendChild(card);
  });
}

subjectSelect.addEventListener("change", renderQuestions);
difficultySelect.addEventListener("change", renderQuestions);

// Initial render
renderQuestions();