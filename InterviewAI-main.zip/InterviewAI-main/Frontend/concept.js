// ====== DARK MODE SYNC ======
const body = document.body;
if (localStorage.getItem("theme") === "dark") body.classList.add("dark-mode");

const themeToggle = document.getElementById("theme-toggle");
if (themeToggle) {
  themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark-mode");
    localStorage.setItem("theme", body.classList.contains("dark-mode") ? "dark" : "light");
    themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
  });
}

// ====== LOGOUT ======
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "index.html";
  });
}
// ===============================
// Accordion Functionality
// ===============================
const accordionButtons = document.querySelectorAll(".accordion-btn");

accordionButtons.forEach(button => {
  button.addEventListener("click", () => {
    const content = button.nextElementSibling;
    const isOpen = content.classList.contains("active");

    // Close all open accordions
    document.querySelectorAll(".accordion-content").forEach(c => {
      c.style.display = "none";
      c.classList.remove("active");
    });

    // Toggle the clicked one
    if (!isOpen) {
      content.style.display = "block";
      content.classList.add("active");
    }
  });
});

// ===============================
// Smooth Scroll Behavior (Optional)
// ===============================
accordionButtons.forEach(button => {
  button.addEventListener("click", () => {
    setTimeout(() => {
      button.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 200);
  });
});