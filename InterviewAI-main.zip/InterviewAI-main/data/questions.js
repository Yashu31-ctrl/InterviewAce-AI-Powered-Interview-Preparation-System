// data/questions.js
const questionData = {
  "Data Structures": {
    "Beginner": [
      {
        id: "ds1",
        question: "What is an array?",
        answer: "An array is a linear data structure that stores elements of the same type in contiguous memory locations."
      },
      {
        id: "ds2",
        question: "What is the difference between stack and queue?",
        answer: "Stack is LIFO (Last In First Out), Queue is FIFO (First In First Out)."
      }
    ],
    "Intermediate": [
      {
        id: "ds3",
        question: "How do you detect a cycle in a linked list?",
        answer: "Use Floyd’s cycle-finding algorithm (two pointers)."
      }
    ],
    "Advanced": [
      {
        id: "ds4",
        question: "Explain how Red-Black Trees maintain balance.",
        answer: "By ensuring properties like every path has same black height and no two red nodes are adjacent."
      }
    ]
  },
  "HTML": {
    "Beginner": [
      {
        id: "html1",
        question: "What does HTML stand for?",
        answer: "HyperText Markup Language."
      },
      {
        id: "html2",
        question: "What is the difference between <div> and <span>?",
        answer: "<div> is a block-level element, <span> is inline."
      }
    ],
    "Intermediate": [
      {
        id: "html3",
        question: "What are semantic HTML elements?",
        answer: "Elements like <article>, <header>, <footer> that convey meaning about content."
      }
    ],
    "Advanced": [
      {
        id: "html4",
        question: "How does HTML5 improve SEO?",
        answer: "By introducing semantic tags that help search engines understand page structure."
      }
    ]
  },
  "CSS": {
    "Beginner": [
      {
        id: "css1",
        question: "What does CSS stand for?",
        answer: "Cascading Style Sheets."
      },
      {
        id: "css2",
        question: "What is the difference between relative and absolute positioning?",
        answer: "Relative is positioned relative to its normal position, absolute is relative to nearest positioned ancestor."
      }
    ],
    "Intermediate": [
      {
        id: "css3",
        question: "Explain the concept of specificity in CSS.",
        answer: "Specificity determines which style rule applies if multiple rules target the same element."
      }
    ],
    "Advanced": [
      {
        id: "css4",
        question: "How does the browser render CSS?",
        answer: "CSS is parsed into a CSSOM which combines with DOM to create the Render Tree."
      }
    ]
  },
  "JavaScript": {
    "Beginner": [
      {
        id: "js1",
        question: "What are JavaScript data types?",
        answer: "Number, String, Boolean, Object, Undefined, Null, Symbol, BigInt."
      }
    ],
    "Intermediate": [
      {
        id: "js2",
        question: "Explain closures in JavaScript.",
        answer: "A closure gives access to an outer function’s scope from an inner function."
      }
    ],
    "Advanced": [
      {
        id: "js3",
        question: "What is the event loop?",
        answer: "It continuously checks the call stack and callback queue to manage asynchronous operations."
      }
    ]
  },
  "Machine Learning": {
    "Beginner": [
      {
        id: "ml1",
        question: "What is supervised learning?",
        answer: "A type of learning using labeled data to train a model."
      }
    ],
    "Intermediate": [
      {
        id: "ml2",
        question: "What is overfitting?",
        answer: "When a model performs well on training data but poorly on unseen data."
      }
    ],
    "Advanced": [
      {
        id: "ml3",
        question: "Explain gradient descent.",
        answer: "An optimization algorithm to minimize loss by iteratively updating weights."
      }
    ]
  }
};
