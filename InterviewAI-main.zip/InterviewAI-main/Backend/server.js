// ====== IMPORTS ======
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
const PORT = 3000;

// ====== MIDDLEWARE ======
app.use(cors());
app.use(bodyParser.json());

// ====== SIMPLE IN-MEMORY DATABASE ======
// (Replace later with MongoDB or MySQL)
let users = {
  "john": {
    password: "1234",
    questionsAttempted: 320,
    accuracy: 82,
    codingChallenges: 45,
    readinessScore: 78,
    learningProgress: 75
  },
  "alice": {
    password: "abcd",
    questionsAttempted: 150,
    accuracy: 70,
    codingChallenges: 20,
    readinessScore: 60,
    learningProgress: 50
  }
};

// ====== SIGNUP ENDPOINT ======
app.post("/api/signup", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password)
    return res.status(400).json({ error: "Username and password required" });

  if (users[username])
    return res.status(400).json({ error: "Username already exists" });

  users[username] = {
    password,
    questionsAttempted: 0,
    accuracy: 0,
    codingChallenges: 0,
    readinessScore: 0,
    learningProgress: 0
  };

  console.log("✅ New user created:", username);
  res.json({ message: "User created successfully" });
});

// ====== LOGIN ENDPOINT ======
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const user = users[username];

  if (!user || user.password !== password)
    return res.status(401).json({ error: "Invalid credentials" });

  console.log("🔐 User logged in:", username);
  res.json({ message: "Login successful", username });
});

// ====== DASHBOARD ENDPOINT ======
app.get("/api/dashboard/:username", (req, res) => {
  const username = req.params.username;
  const user = users[username];

  if (!user) return res.status(404).json({ error: "User not found" });

  const { questionsAttempted, accuracy, codingChallenges, readinessScore, learningProgress } = user;
  res.json({ username, questionsAttempted, accuracy, codingChallenges, readinessScore, learningProgress });
});

// ====== HOME ROUTE ======
app.get("/", (req, res) => {
  res.send("✅ Backend is running successfully! Use /api routes.");
});

// ====== START SERVER ======
app.listen(PORT, () => {
  console.log(`🚀 Backend running at http://localhost:${PORT}`);
});